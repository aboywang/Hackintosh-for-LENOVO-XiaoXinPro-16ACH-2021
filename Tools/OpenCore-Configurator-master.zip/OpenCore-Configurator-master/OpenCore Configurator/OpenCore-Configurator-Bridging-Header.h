#ifndef OpenCore_Configurator_Bridging_Header_h
#define OpenCore_Configurator_Bridging_Header_h
#import <CommonCrypto/CommonDigest.h>


#endif /* OpenCore_Configurator_Bridging_Header_h */
